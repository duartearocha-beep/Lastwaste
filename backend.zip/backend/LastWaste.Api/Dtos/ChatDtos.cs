namespace LastWaste.Api.Dtos;

public class ChatRequest
{
    public string? ConversationId { get; set; }
    public string Message { get; set; } = "";
}

public class ChatResponse
{
    public string ConversationId { get; set; } = "";
    public string Reply { get; set; } = "";
}
