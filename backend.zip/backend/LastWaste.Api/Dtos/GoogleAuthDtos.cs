namespace LastWaste.Api.Dtos;

public class GoogleLoginRequest
{
    public string IdToken { get; set; } = "";
}
