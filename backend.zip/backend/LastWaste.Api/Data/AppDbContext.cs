using LastWaste.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace LastWaste.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Categoria> Categorias { get; set; }
    public DbSet<Transacao> Transacoes { get; set; }
    public DbSet<Orcamento> Orcamentos { get; set; }

    // ✅ Utilizadores (já tens)
    public DbSet<Utilizador> Utilizadores { get; set; }

    // ✅ NOVO: Lembretes
    public DbSet<Lembrete> Lembretes { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // --- CATEGORIA ---
        modelBuilder.Entity<Categoria>()
            .HasKey(c => c.IdCategoria);

        // --- TRANSACAO ---
        modelBuilder.Entity<Transacao>()
            .HasKey(t => t.IdTransacao);

        modelBuilder.Entity<Transacao>()
            .Property(t => t.Valor)
            .HasColumnType("decimal(10,2)");

        modelBuilder.Entity<Transacao>()
            .HasOne(t => t.Categoria)
            .WithMany()
            .HasForeignKey(t => t.IdCategoria)
            .OnDelete(DeleteBehavior.Restrict);

        // --- ORCAMENTO ---
        modelBuilder.Entity<Orcamento>()
            .HasKey(o => o.IdOrcamento);

        modelBuilder.Entity<Orcamento>()
            .Property(o => o.Limite)
            .HasColumnType("decimal(10,2)");

        modelBuilder.Entity<Orcamento>()
            .HasOne(o => o.Categoria)
            .WithMany()
            .HasForeignKey(o => o.IdCategoria)
            .OnDelete(DeleteBehavior.Restrict);

        // --- UTILIZADOR ---
        modelBuilder.Entity<Utilizador>()
            .HasKey(u => u.IdUtilizador);

        // ✅ NOVO: LEMBRETE
        modelBuilder.Entity<Lembrete>()
            .HasKey(l => l.IdLembrete);
    }
}
