using System.Text;
using System.Text.Json;

namespace LastWaste.Api.Services;

public class GeminiClient
{
    private readonly HttpClient _http;
    private readonly IConfiguration _cfg;

    public GeminiClient(HttpClient http, IConfiguration cfg)
    {
        _http = http;
        _cfg = cfg;
    }

    public async Task<string> GenerateAsync(List<(string role, string text)> history)
    {
        var apiKey = _cfg["Gemini:ApiKey"] ?? throw new Exception("Gemini:ApiKey em falta");
        var model = _cfg["Gemini:Model"] ?? "gemini-2.5-flash";

        var contents = history.Select(m => new
        {
            role = m.role, // "user" | "model"
            parts = new[] { new { text = m.text } }
        });

        var body = new
        {
            contents,
            generationConfig = new { temperature = 0.7 }
        };

        var json = JsonSerializer.Serialize(body);
        var url = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";

        using var res = await _http.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
        var resBody = await res.Content.ReadAsStringAsync();

        if (!res.IsSuccessStatusCode)
            throw new Exception($"Gemini error {(int)res.StatusCode}: {resBody}");

        using var doc = JsonDocument.Parse(resBody);
        var text = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        return text ?? "";
    }
}
