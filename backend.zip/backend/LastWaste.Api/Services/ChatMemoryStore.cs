using System.Collections.Concurrent;

namespace LastWaste.Api.Services;

public class ChatMemoryStore
{
    private readonly ConcurrentDictionary<string, List<(string role, string text)>> _store = new();

    public string EnsureConversation(string? id)
    {
        var cid = string.IsNullOrWhiteSpace(id) ? Guid.NewGuid().ToString("N") : id;
        _store.TryAdd(cid, new List<(string role, string text)>());
        return cid;
    }

    public List<(string role, string text)> GetHistory(string cid)
        => _store.TryGetValue(cid, out var h) ? h : new List<(string role, string text)>();

    public void Append(string cid, string role, string text)
    {
        var list = _store.GetOrAdd(cid, _ => new List<(string role, string text)>());
        list.Add((role, text));

        // limite para não crescer infinito
        if (list.Count > 40)
            list.RemoveRange(0, list.Count - 40);
    }
}
