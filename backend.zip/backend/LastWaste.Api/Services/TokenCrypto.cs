using System.Security.Cryptography;
using System.Text;

namespace LastWaste.Api.Services;

public static class TokenCrypto
{
    public static string Sha256Hex(string input)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes).ToLowerInvariant();
    }

    public static string NewResetToken()
    {
        var raw = RandomNumberGenerator.GetBytes(32);
        return Convert.ToBase64String(raw)
            .Replace("+", "-")
            .Replace("/", "_")
            .Replace("=", "");
    }
}
