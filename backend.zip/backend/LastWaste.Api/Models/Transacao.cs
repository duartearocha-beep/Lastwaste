using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LastWaste.Api.Models;

[Table("transacao")] // ✅ nome real da tua tabela
public class Transacao
{
    [Key]
    [Column("id_transacao")]
    public int IdTransacao { get; set; }

    [Column("id_utilizador")]
    public int IdUtilizador { get; set; }

    [Column("id_categoria")]
    public int IdCategoria { get; set; }

    [Column("tipo")]
    public string Tipo { get; set; } = "despesa";

    [Column("valor", TypeName = "decimal(10,2)")]
    public decimal Valor { get; set; }

    [Column("data_transacao")]
    public DateTime DataTransacao { get; set; }

    [Column("descricao")]
    public string? Descricao { get; set; }

    [Column("data_registo")]
    public DateTime? DataRegisto { get; set; }

    // ✅ navegação opcional (não cria coluna extra porque a FK é IdCategoria)
    [ForeignKey(nameof(IdCategoria))]
    public Categoria? Categoria { get; set; }
}
