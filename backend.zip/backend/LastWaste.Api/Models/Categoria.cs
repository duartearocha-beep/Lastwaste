using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LastWaste.Api.Models;

[Table("categoria")]
public class Categoria
{
    [Key]
    [Column("id_categoria")]
    public int IdCategoria { get; set; }

    [Column("id_utilizador")]
    public int IdUtilizador { get; set; }

    [Column("nome")]
    public string Nome { get; set; } = "";

    [Column("tipo")]
    public string Tipo { get; set; } = "despesa";

    // ✅ Só para compilar (não vai para a BD)
    [NotMapped]
    public string? Cor { get; set; }
}
