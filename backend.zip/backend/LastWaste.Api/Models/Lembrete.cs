using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LastWaste.Api.Models;

[Table("lembrete")]
public class Lembrete
{
    [Key]
    [Column("id_lembrete")]
    public int IdLembrete { get; set; }

    [Required]
    [Column("id_utilizador")]
    public int IdUtilizador { get; set; }

    [Required]
    [MaxLength(100)]
    [Column("titulo")]
    public string Titulo { get; set; } = "";

    [Column("mensagem")]
    public string? Mensagem { get; set; }

    [Required]
    [Column("data_lembrete")]
    public DateTime DataLembrete { get; set; }

    [Required]
    [Column("estado")]
    public string Estado { get; set; } = "pendente";
}
