using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LastWaste.Api.Models
{
    [Table("orcamento")]
    public class Orcamento
    {
        [Key]
        [Column("id_orcamento")]
        public int IdOrcamento { get; set; }

        [Required]
        [Column("id_utilizador")]
        public int IdUtilizador { get; set; }

        [Required]
        [Column("id_categoria")]
        public int IdCategoria { get; set; }

        // ✅ Navegação (isto resolve o erro do AppDbContext)
        [ForeignKey(nameof(IdCategoria))]
        public Categoria? Categoria { get; set; }

        [Required]
        [Column("limite", TypeName = "decimal(10,2)")]
        public decimal Limite { get; set; }

        [Required]
        [Column("periodo_inicio")]
        public DateTime PeriodoInicio { get; set; }

        [Required]
        [Column("periodo_fim")]
        public DateTime PeriodoFim { get; set; }
    }
}
