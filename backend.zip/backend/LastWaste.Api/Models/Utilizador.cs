using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LastWaste.Api.Models;

[Table("utilizador")]
public class Utilizador
{
    [Key]
    [Column("id_utilizador")]
    public int IdUtilizador { get; set; }

    [Required]
    [Column("nome")]
    [MaxLength(100)]
    public string Nome { get; set; } = string.Empty;

    [Required]
    [Column("email")]
    [MaxLength(150)]
    public string Email { get; set; } = string.Empty;

    // local / google
    [Required]
    [Column("provedor")]
    [MaxLength(50)]
    public string Provedor { get; set; } = "local";

    // ✅ Local login
    [Column("password_hash")]
    [MaxLength(255)]
    public string? PasswordHash { get; set; }

    [Column("reset_token_hash")]
    [MaxLength(255)]
    public string? ResetTokenHash { get; set; }

    [Column("reset_token_expires")]
    public DateTime? ResetTokenExpires { get; set; }

    // ✅ Google login (novo)
    [Column("provider_user_id")]
    [MaxLength(255)]
    public string? ProviderUserId { get; set; }

    [Column("foto_url")]
    [MaxLength(255)]
    public string? FotoUrl { get; set; }

    [Column("criado_em")]
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    [Column("ultimo_login")]
    public DateTime? UltimoLogin { get; set; }
}
