using LastWaste.Api.Data;
using LastWaste.Api.Dtos;
using LastWaste.Api.Models;
using LastWaste.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LastWaste.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthLocalController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly PasswordService _pwd;
    private readonly JwtTokenService _jwt;
    private readonly ILogger<AuthLocalController> _logger;
    private readonly IConfiguration _cfg;

    public AuthLocalController(
        AppDbContext db,
        PasswordService pwd,
        JwtTokenService jwt,
        ILogger<AuthLocalController> logger,
        IConfiguration cfg)
    {
        _db = db;
        _pwd = pwd;
        _jwt = jwt;
        _logger = logger;
        _cfg = cfg;
    }

    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register([FromBody] RegisterRequest req)
    {
        req.Email = (req.Email ?? "").Trim().ToLowerInvariant();
        req.Nome = (req.Nome ?? "").Trim();

        if (string.IsNullOrWhiteSpace(req.Nome) ||
            string.IsNullOrWhiteSpace(req.Email) ||
            string.IsNullOrWhiteSpace(req.Password))
            return BadRequest("Dados inválidos.");

        var exists = await _db.Set<Utilizador>().AnyAsync(u => u.Email == req.Email);
        if (exists) return Conflict("Email já registado.");

        var user = new Utilizador
        {
            Nome = req.Nome,
            Email = req.Email,
            Provedor = "local",
            PasswordHash = _pwd.HashPassword(req.Password)
        };

        _db.Add(user);
        await _db.SaveChangesAsync();

        var token = _jwt.CreateToken(user);

        return Ok(new AuthResponse
        {
            Token = token,
            User = new { user.IdUtilizador, user.Nome, user.Email }
        });
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login([FromBody] LoginRequest req)
    {
        var email = (req.Email ?? "").Trim().ToLowerInvariant();
        var pass = req.Password ?? "";

        var user = await _db.Set<Utilizador>().FirstOrDefaultAsync(u => u.Email == email);
        if (user == null || string.IsNullOrWhiteSpace(user.PasswordHash))
            return Unauthorized("Credenciais inválidas.");

        if (!_pwd.VerifyPassword(pass, user.PasswordHash))
            return Unauthorized("Credenciais inválidas.");

        var token = _jwt.CreateToken(user);

        return Ok(new AuthResponse
        {
            Token = token,
            User = new { user.IdUtilizador, user.Nome, user.Email }
        });
    }

    // ✅ MODO DEV: imprime link no terminal
    [HttpPost("forgot-password")]
    public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest req)
    {
        var email = (req.Email ?? "").Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(email))
            return BadRequest("Email inválido.");

        var user = await _db.Set<Utilizador>().FirstOrDefaultAsync(u => u.Email == email);
        if (user == null)
        {
            // não revelar se existe ou não (boa prática)
            return Ok(new { message = "Se o email existir, será gerado um link de recuperação." });
        }

        var token = TokenCrypto.NewResetToken();
        user.ResetTokenHash = TokenCrypto.Sha256Hex(token);
        user.ResetTokenExpires = DateTime.UtcNow.AddMinutes(20);

        await _db.SaveChangesAsync();

        var feBase = _cfg["Frontend:BaseUrl"] ?? "http://localhost:5173";
        var link = $"{feBase}/reset-password?email={Uri.EscapeDataString(email)}&token={Uri.EscapeDataString(token)}";

        _logger.LogWarning("DEV RESET LINK (copiar e abrir no browser): {Link}", link);

        return Ok(new { message = "Se o email existir, será gerado um link de recuperação." });
    }

    [HttpPost("reset-password")]
    public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest req)
    {
        var email = (req.Email ?? "").Trim().ToLowerInvariant();
        var token = (req.Token ?? "").Trim();
        var newPass = req.NewPassword ?? "";

        if (string.IsNullOrWhiteSpace(email) ||
            string.IsNullOrWhiteSpace(token) ||
            string.IsNullOrWhiteSpace(newPass))
            return BadRequest("Dados inválidos.");

        var user = await _db.Set<Utilizador>().FirstOrDefaultAsync(u => u.Email == email);
        if (user == null || string.IsNullOrWhiteSpace(user.ResetTokenHash) || user.ResetTokenExpires == null)
            return BadRequest("Token inválido.");

        if (user.ResetTokenExpires < DateTime.UtcNow)
            return BadRequest("Token expirado.");

        var tokenHash = TokenCrypto.Sha256Hex(token);
        if (!string.Equals(tokenHash, user.ResetTokenHash, StringComparison.OrdinalIgnoreCase))
            return BadRequest("Token inválido.");

        user.PasswordHash = _pwd.HashPassword(newPass);
        user.ResetTokenHash = null;
        user.ResetTokenExpires = null;

        await _db.SaveChangesAsync();

        return Ok(new { message = "Password atualizada com sucesso." });
    }
}
