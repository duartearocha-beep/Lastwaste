using System.Security.Claims;
using LastWaste.Api.Data;
using LastWaste.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LastWaste.Api.Controllers;

[ApiController]
[Route("api/lembretes")]
[Authorize]
public class LembretesController : ControllerBase
{
    private readonly AppDbContext _db;

    public LembretesController(AppDbContext db)
    {
        _db = db;
    }

    // ✅ NOVO: GET /api/lembretes/notificacoes
    [HttpGet("notificacoes")]
    public async Task<IActionResult> Notificacoes()
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var agora = DateTime.Now;
        var limite = agora.AddDays(3); // próximos 3 dias

        var lembretes = await _db.Lembretes
            .Where(l =>
                l.IdUtilizador == userId.Value &&
                l.Estado == "pendente" &&
                l.DataLembrete <= limite
            )
            .OrderBy(l => l.DataLembrete)
            .ToListAsync();

        return Ok(lembretes);
    }

    // GET /api/lembretes
    [HttpGet]
    public async Task<IActionResult> Listar()
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var lista = await _db.Lembretes
            .Where(l => l.IdUtilizador == userId.Value)
            .OrderBy(l => l.Estado == "concluido")
            .ThenBy(l => l.DataLembrete)
            .ToListAsync();

        return Ok(lista);
    }

    // GET /api/lembretes/{id}
    [HttpGet("{id:int}")]
    public async Task<IActionResult> ObterPorId(int id)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var lembrete = await _db.Lembretes
            .FirstOrDefaultAsync(l => l.IdLembrete == id && l.IdUtilizador == userId.Value);

        return lembrete == null ? NotFound() : Ok(lembrete);
    }

    // POST /api/lembretes
    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CriarLembreteRequest req)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        if (string.IsNullOrWhiteSpace(req.Tipo))
            return BadRequest("Tipo (título) é obrigatório.");

        if (req.DataLembrete == default)
            return BadRequest("Data do lembrete é obrigatória.");

        var estado = string.IsNullOrWhiteSpace(req.Estado)
            ? "pendente"
            : req.Estado.Trim().ToLowerInvariant();

        if (!EstadoValido(estado)) estado = "pendente";

        var lembrete = new Lembrete
        {
            IdUtilizador = userId.Value,
            Titulo = req.Tipo.Trim(),
            Mensagem = string.IsNullOrWhiteSpace(req.Mensagem) ? null : req.Mensagem.Trim(),
            DataLembrete = req.DataLembrete,
            Estado = estado
        };

        _db.Lembretes.Add(lembrete);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(ObterPorId), new { id = lembrete.IdLembrete }, lembrete);
    }

    // PUT /api/lembretes/{id}
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Atualizar(int id, [FromBody] AtualizarLembreteRequest req)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var lembrete = await _db.Lembretes
            .FirstOrDefaultAsync(l => l.IdLembrete == id && l.IdUtilizador == userId.Value);

        if (lembrete == null) return NotFound();

        if (!string.IsNullOrWhiteSpace(req.Tipo))
            lembrete.Titulo = req.Tipo.Trim();

        lembrete.Mensagem = string.IsNullOrWhiteSpace(req.Mensagem) ? null : req.Mensagem.Trim();

        if (req.DataLembrete.HasValue && req.DataLembrete.Value != default)
            lembrete.DataLembrete = req.DataLembrete.Value;

        if (!string.IsNullOrWhiteSpace(req.Estado))
        {
            var estado = req.Estado.Trim().ToLowerInvariant();
            if (EstadoValido(estado))
                lembrete.Estado = estado;
        }

        await _db.SaveChangesAsync();
        return Ok(lembrete);
    }

    // PATCH /api/lembretes/{id}/concluir
    [HttpPatch("{id:int}/concluir")]
    public async Task<IActionResult> Concluir(int id)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var lembrete = await _db.Lembretes
            .FirstOrDefaultAsync(l => l.IdLembrete == id && l.IdUtilizador == userId.Value);

        if (lembrete == null) return NotFound();

        lembrete.Estado = "concluido";
        await _db.SaveChangesAsync();

        return Ok(lembrete);
    }

    // DELETE /api/lembretes/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Apagar(int id)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var lembrete = await _db.Lembretes
            .FirstOrDefaultAsync(l => l.IdLembrete == id && l.IdUtilizador == userId.Value);

        if (lembrete == null) return NotFound();

        _db.Lembretes.Remove(lembrete);
        await _db.SaveChangesAsync();

        return NoContent();
    }

    private int? GetUserId()
    {
        var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return int.TryParse(idStr, out var id) ? id : null;
    }

    private static bool EstadoValido(string estado)
        => estado is "pendente" or "enviado" or "concluido";
}

public class CriarLembreteRequest
{
    public string Tipo { get; set; } = "";
    public string? Mensagem { get; set; }
    public DateTime DataLembrete { get; set; }
    public string? Estado { get; set; }
}

public class AtualizarLembreteRequest
{
    public string? Tipo { get; set; }
    public string? Mensagem { get; set; }
    public DateTime? DataLembrete { get; set; }
    public string? Estado { get; set; }
}
