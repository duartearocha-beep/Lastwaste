using LastWaste.Api.Data;
using LastWaste.Api.Dtos;
using LastWaste.Api.Models;
using LastWaste.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;
using System.Text.Json;

namespace LastWaste.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly JwtTokenService _jwt;
    private readonly IHttpClientFactory _httpFactory;

    public AuthController(AppDbContext db, JwtTokenService jwt, IHttpClientFactory httpFactory)
    {
        _db = db;
        _jwt = jwt;
        _httpFactory = httpFactory;
    }

    // POST /api/auth/google
    [HttpPost("google")]
    public async Task<IActionResult> GoogleLogin([FromBody] GoogleLoginRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.IdToken))
            return BadRequest("IdToken em falta.");

        // 1) Validar token do Google e obter perfil
        var profile = await VerifyGoogleToken(req.IdToken);
        if (profile == null || string.IsNullOrWhiteSpace(profile.Sub) || string.IsNullOrWhiteSpace(profile.Email))
            return Unauthorized("Token Google inválido.");

        var providerUserId = profile.Sub;
        var email = profile.Email.Trim().ToLowerInvariant();
        var nome = string.IsNullOrWhiteSpace(profile.Name) ? email : profile.Name.Trim();
        var foto = profile.Picture;

        // 2) Encontrar utilizador (por provider_user_id ou email)
        var user = await _db.Set<Utilizador>()
            .FirstOrDefaultAsync(u =>
                (u.Provedor == "google" && u.ProviderUserId == providerUserId) ||
                u.Email == email
            );

        if (user == null)
        {
            user = new Utilizador
            {
                Nome = nome,
                Email = email,
                Provedor = "google",
                ProviderUserId = providerUserId,
                FotoUrl = foto,
                CriadoEm = DateTime.UtcNow,
                UltimoLogin = DateTime.UtcNow
            };

            _db.Add(user);
        }
        else
        {
            // Se já existia como "local", podemos manter, mas associar google
            user.Nome = user.Nome ?? nome;
            user.Email = email;

            user.Provedor = "google";
            user.ProviderUserId = providerUserId;
            user.FotoUrl = foto;
            user.UltimoLogin = DateTime.UtcNow;
        }

        await _db.SaveChangesAsync();

        // 3) JWT
        var token = _jwt.CreateToken(user);

        return Ok(new
        {
            token,
            user = new
            {
                user.IdUtilizador,
                user.Nome,
                user.Email,
                user.Provedor,
                user.FotoUrl
            }
        });
    }

    private async Task<GoogleTokenInfo?> VerifyGoogleToken(string idToken)
    {
        // Endpoint oficial para validar id_token:
        // https://oauth2.googleapis.com/tokeninfo?id_token=...
        var client = _httpFactory.CreateClient();
        var url = $"https://oauth2.googleapis.com/tokeninfo?id_token={Uri.EscapeDataString(idToken)}";

        using var res = await client.GetAsync(url);
        if (!res.IsSuccessStatusCode) return null;

        var json = await res.Content.ReadAsStringAsync();
        try
        {
            return JsonSerializer.Deserialize<GoogleTokenInfo>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });
        }
        catch
        {
            return null;
        }
    }

    private class GoogleTokenInfo
    {
        public string? Sub { get; set; }        // user id
        public string? Email { get; set; }
        public string? Name { get; set; }
        public string? Picture { get; set; }

        // extra fields possíveis: aud, iss, exp...
        public string? Aud { get; set; }
        public string? Iss { get; set; }
    }
}
