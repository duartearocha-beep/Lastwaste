using Microsoft.AspNetCore.Mvc;
using LastWaste.Api.Data;
using LastWaste.Api.Models;

namespace LastWaste.Api.Controllers
{
    [ApiController]
    [Route("api/orcamentos")]
    public class OrcamentosController : ControllerBase
    {
        private readonly AppDbContext _db;

        public OrcamentosController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("{userId}")]
        public IActionResult GetAll(int userId)
        {
            var orcamentos = _db.Orcamentos
                .Where(o => o.IdUtilizador == userId)
                .OrderByDescending(o => o.PeriodoInicio)
                .ToList();

            return Ok(orcamentos);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Orcamento orcamento)
        {
            _db.Orcamentos.Add(orcamento);
            _db.SaveChanges();
            return Ok(orcamento);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Orcamento dto)
        {
            var orcamento = _db.Orcamentos.FirstOrDefault(o => o.IdOrcamento == id);
            if (orcamento == null) return NotFound();

            orcamento.IdUtilizador = dto.IdUtilizador;
            orcamento.IdCategoria = dto.IdCategoria;
            orcamento.Limite = dto.Limite;
            orcamento.PeriodoInicio = dto.PeriodoInicio;
            orcamento.PeriodoFim = dto.PeriodoFim;

            _db.SaveChanges();
            return Ok(orcamento);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var orcamento = _db.Orcamentos.FirstOrDefault(o => o.IdOrcamento == id);
            if (orcamento == null) return NotFound();

            _db.Orcamentos.Remove(orcamento);
            _db.SaveChanges();
            return Ok();
        }
    }
}
