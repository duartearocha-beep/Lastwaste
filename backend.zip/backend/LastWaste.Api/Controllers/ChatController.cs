using LastWaste.Api.Dtos;
using LastWaste.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace LastWaste.Api.Controllers;

[ApiController]
[Route("api/chat")]
public class ChatController : ControllerBase
{
    private readonly ChatMemoryStore _store;
    private readonly GeminiClient _gemini;

    public ChatController(ChatMemoryStore store, GeminiClient gemini)
    {
        _store = store;
        _gemini = gemini;
    }

    [HttpPost]
    public async Task<ActionResult<ChatResponse>> Post([FromBody] ChatRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Message))
            return BadRequest("Mensagem vazia.");

        var cid = _store.EnsureConversation(req.ConversationId);

        _store.Append(cid, "user", req.Message);

        var reply = await _gemini.GenerateAsync(_store.GetHistory(cid));

        _store.Append(cid, "model", reply);

        return Ok(new ChatResponse
        {
            ConversationId = cid,
            Reply = reply
        });
    }
}
