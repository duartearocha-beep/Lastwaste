using Microsoft.AspNetCore.Mvc;
using LastWaste.Api.Data;
using LastWaste.Api.Models;

namespace LastWaste.Api.Controllers
{
    [ApiController]
    [Route("api/categorias")]
    public class CategoriasController : ControllerBase
    {
        private readonly AppDbContext _db;

        public CategoriasController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("{userId}")]
        public IActionResult GetAll(int userId)
        {
            var categorias = _db.Categorias
                .Where(c => c.IdUtilizador == userId)
                .OrderBy(c => c.Nome)
                .ToList();

            return Ok(categorias);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Categoria categoria)
        {
            _db.Categorias.Add(categoria);
            _db.SaveChanges();
            return Ok(categoria);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Categoria dto)
        {
            var categoria = _db.Categorias.FirstOrDefault(c => c.IdCategoria == id);
            if (categoria == null) return NotFound();

            categoria.Nome = dto.Nome;
            categoria.Tipo = dto.Tipo;
            categoria.Cor = dto.Cor;
            categoria.IdUtilizador = dto.IdUtilizador;

            _db.SaveChanges();
            return Ok(categoria);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var categoria = _db.Categorias.FirstOrDefault(c => c.IdCategoria == id);
            if (categoria == null) return NotFound();

            _db.Categorias.Remove(categoria);
            _db.SaveChanges();
            return Ok();
        }
    }
}

