using LastWaste.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using LastWaste.Api.Data;

namespace LastWaste.Api.Controllers;

[ApiController]
[Route("api/transacoes")]
[Authorize]
public class TransacoesController : ControllerBase
{
    private readonly AppDbContext _db;

    public TransacoesController(AppDbContext db)
    {
        _db = db;
    }

    // GET /api/transacoes?dataInicio=YYYY-MM-DD&dataFim=YYYY-MM-DD
    [HttpGet]
    public async Task<IActionResult> Listar(
        [FromQuery] DateTime? dataInicio,
        [FromQuery] DateTime? dataFim)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var query = _db.Transacoes
            .Include(t => t.Categoria)
            .Where(t => t.IdUtilizador == userId.Value)
            .AsQueryable();

        if (dataInicio.HasValue)
        {
            var ini = dataInicio.Value.Date;
            query = query.Where(t => t.DataTransacao >= ini);
        }

        if (dataFim.HasValue)
        {
            var fim = dataFim.Value.Date.AddDays(1).AddTicks(-1);
            query = query.Where(t => t.DataTransacao <= fim);
        }

        var lista = await query
            .OrderByDescending(t => t.DataTransacao)
            .ToListAsync();

        return Ok(lista);
    }

    // POST /api/transacoes
    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CriarTransacaoRequest req)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        if (req.IdCategoria <= 0)
            return BadRequest("Categoria inválida.");

        if (req.Valor <= 0)
            return BadRequest("Valor inválido.");

        if (string.IsNullOrWhiteSpace(req.Tipo))
            req.Tipo = "despesa";

        var categoria = await _db.Categorias
            .FirstOrDefaultAsync(c =>
                c.IdCategoria == req.IdCategoria &&
                c.IdUtilizador == userId.Value);

        if (categoria == null)
            return BadRequest("Categoria não encontrada.");

        var t = new Transacao
        {
            IdUtilizador = userId.Value,
            IdCategoria = req.IdCategoria,
            Tipo = req.Tipo.Trim().ToLowerInvariant(),
            Valor = req.Valor,
            DataTransacao = req.DataTransacao,
            Descricao = req.Descricao,
            DataRegisto = DateTime.UtcNow
        };

        _db.Transacoes.Add(t);
        await _db.SaveChangesAsync();

        await _db.Entry(t)
            .Reference(x => x.Categoria)
            .LoadAsync();

        return CreatedAtAction(nameof(Listar), new { id = t.IdTransacao }, t);
    }

    // DELETE /api/transacoes/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Apagar(int id)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        var t = await _db.Transacoes
            .FirstOrDefaultAsync(x =>
                x.IdTransacao == id &&
                x.IdUtilizador == userId.Value);

        if (t == null) return NotFound();

        _db.Transacoes.Remove(t);
        await _db.SaveChangesAsync();

        return NoContent();
    }

    // POST /api/transacoes/import
    [HttpPost("import")]
    public async Task<IActionResult> Importar([FromBody] ImportTransacoesRequest req)
    {
        var userId = GetUserId();
        if (userId == null) return Unauthorized();

        foreach (var t in req.Transacoes)
        {
            var nova = new Transacao
            {
                IdUtilizador = userId.Value,
                IdCategoria = t.IdCategoria,
                Valor = t.Valor,
                Tipo = t.Tipo,
                Descricao = t.Descricao,
                DataTransacao = t.DataTransacao,
                DataRegisto = DateTime.UtcNow
            };

            _db.Transacoes.Add(nova);
        }

        await _db.SaveChangesAsync();
        return Ok();
    }

    private int? GetUserId()
    {
        var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return int.TryParse(idStr, out var id) ? id : null;
    }
}

/* ===========================
   DTOs / REQUESTS (FORA DO CONTROLLER)
   =========================== */

public class CriarTransacaoRequest
{
    public int IdCategoria { get; set; }
    public string Tipo { get; set; } = "despesa";
    public decimal Valor { get; set; }
    public DateTime DataTransacao { get; set; }
    public string? Descricao { get; set; }
}

public class ImportTransacoesRequest
{
    public List<ImportTransacaoDto> Transacoes { get; set; } = new();
}

public class ImportTransacaoDto
{
    public int IdCategoria { get; set; }
    public decimal Valor { get; set; }
    public string Tipo { get; set; } = "";
    public string? Descricao { get; set; }
    public DateTime DataTransacao { get; set; }
}
